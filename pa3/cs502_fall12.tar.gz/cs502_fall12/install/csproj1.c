#include <stdio.h>
#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "tm.h"
#include "tree.h"
#include "cgraph.h"
#include "hashtab.h"
#include "tree-iterator.h"

void cs502_proj1()
{

  
  struct cgraph_node *node;
  struct cgraph_node *node_end;
  tree fndecl;
  

  printf ("*****************\n you may want add your code here\n **************\n");
  //traverse all functions
  for (node = cgraph_nodes; node; node = node->next) {
    fndecl = node->decl;
    //TODO : unparsing a function
  }
  
}

