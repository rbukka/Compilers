main()
{
  int x;
  int i = 0;
  printf("Please input 1st value: ");
  scanf("%d", &x);
  switch(x){
  case 0:printf("zeor\n");
		break;
  case 1:printf("one\n");
    break;
  case 2:printf("two\n");
    break;
  default:
    break;
  }

}


