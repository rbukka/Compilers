float g1;
float g2;

float add(float a, float b){
  return a+b;
}

float sub(float a, float b){
  return a-b;
}

char other(char a, char b){

  return a;

}

int boolcal(int a, int b, int c) {
  return (a>b) && (a>c) || (b>c);
}

main()
{
    printf("Hello World\n");
    g1 = 10.5;
    g2 = 2.0;

    printf("g1+g2 = %f\n", add(g1,g2));
    printf("g1-g2 = %f\n", sub(g1,g2));
    printf("other %c\n", other('0','1'));
    printf("boolcal %d\n", boolcal(1, 2, 3));

    return 0;
}
